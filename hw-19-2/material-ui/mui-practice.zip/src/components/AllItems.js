import React from 'react';

const Allitems = () => {
  return (
    <div>
      
    </div>
  );
}

export default Allitems;

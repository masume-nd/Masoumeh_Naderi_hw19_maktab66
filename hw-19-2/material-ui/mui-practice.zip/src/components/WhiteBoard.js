import React from 'react';

const Whiteboard = () => {
  return (
    <div>
      
    </div>
  );
}

export default Whiteboard;

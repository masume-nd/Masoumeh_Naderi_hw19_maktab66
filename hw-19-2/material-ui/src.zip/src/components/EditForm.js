import React, {useState} from "react";
import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import TextField from "@mui/material/TextField";
import Button from '@mui/material/Button';

const style = {
  width: 300,
  height: 400,
  border: "none",
  m: "auto",
  p: 4,
  display:"flex",
  flexDirection:"column"
};
const Editform = ({item, setItem}) => {

  const [editedItem, setEditedItem] = useState(item);

  const handleChange = (newItem) => {
    setItem(newItem)
  }
   return (
      <>
         <Box sx={style}>
            <TextField
               id="standard-basic"
               variant="standard"
               value={item?.title}
            />
            <FormControl variant="standard" sx={{ my: 3, minWidth: 140 }}>
               <InputLabel id="demo-simple-select-standard-label">
                  Skills
               </InputLabel>
               <Select
                  labelId="demo-simple-select-standard-label"
                  id="demo-simple-select-standard"
                  // value={age}
                  onChange={handleChange}
                  label="Age"
               >
                  <MenuItem value={10}>Web Designe</MenuItem>
                  <MenuItem value={20}>Front End</MenuItem>
                  <MenuItem value={30}>Back End</MenuItem>
               </Select>
            </FormControl>
            <TextField
               sx={{ pb: 3 }}
               id="standard-basic"
               value={item?.desc}
               variant="standard"
               multiline
               rows={4}
            />
            <Button  variant="text">
               Edit
            </Button>
         </Box>
      </>
   );
};

export default Editform;

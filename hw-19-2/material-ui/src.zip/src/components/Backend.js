import React, { useContext, useState } from "react";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import ListItemButton from "@mui/material/ListItemButton";
import { Typography } from "@mui/material";
import { ItemsContext } from "./MyContext";
const Backend = ({activeHandle}) => {
   const [active, setActive] = useState(false);
   const { frontend, backend, webDesign } = useContext(ItemsContext);
   const clickHandler = (item) => {
      setActive(item);
      activeHandle(item);
   };
   return (
      <>
         <Typography sx={{ textAlign: "center" }} variant="h4">
            Back-End
         </Typography>
         {backend.map((item) => {
            return (
               <List
                  sx={{ p: 0 }}
                  key={item.title}
                  active={active === item}
                  onClick={() => clickHandler(item)}
               >
                  <ListItemButton>
                     <ListItem>
                        <ListItemText>{item.title}</ListItemText>
                        <ListItemIcon>
                           <DeleteIcon />
                        </ListItemIcon>
                        <ListItemIcon>
                           <EditIcon />
                        </ListItemIcon>
                     </ListItem>
                  </ListItemButton>
               </List>
            );
         })}
      </>
   );
};

export default Backend;
